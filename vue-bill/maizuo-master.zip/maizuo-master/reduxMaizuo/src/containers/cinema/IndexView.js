/**
 * Created by zhengguorong on 16/7/1.
 */
import React from 'react'

class CinemaIndexView extends React.Component{
  render(){
    return (
      <section style={{margin:'50px auto',textAlign: 'center'}}>
        <div>该页面正在开发中。。。</div>
      </section>
    )
  }
}
export default CinemaIndexView
