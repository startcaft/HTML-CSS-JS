# redux卖座网

> react+redux+react-router-redux+webpack开发的卖座网

## Build Setup

``` bash
# 安装依赖
npm install

# serve with hot reload at localhost:8000
npm run start

