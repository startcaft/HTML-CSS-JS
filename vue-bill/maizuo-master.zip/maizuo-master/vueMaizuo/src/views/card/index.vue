<template>
	<section class='cinema'>
			<div>该页面正在开发中。。。</div>
	</section>
</template>

<style lang='scss'>
	.cinema {
		margin:50px auto;
		text-align: center;
	}
</style>