export const getComingSoonFilms = state => state.comingSoonFilms
export const getNowPlayingFilms = state => state.nowPlayingFilms
export const getDetail = state => state.detail
export const getBillboards = state => state.billboards
