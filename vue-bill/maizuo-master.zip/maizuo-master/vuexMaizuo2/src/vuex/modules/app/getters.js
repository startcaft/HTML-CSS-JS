export const getLeftNavState = state => state.leftNavState
export const getLoading = state => state.loading
