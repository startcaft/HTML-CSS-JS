import { Component } from '@angular/core';

@Component({
  selector: 'index-view',
  template: '<h1>this is card view</h1>'
})
export class CardView { }
