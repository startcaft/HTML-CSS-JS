import { Component } from '@angular/core';

@Component({
  selector: 'index-view',
  templateUrl: './index.view.html',
  styleUrls: ['./index.view.css']
})
export class IndexView { }
