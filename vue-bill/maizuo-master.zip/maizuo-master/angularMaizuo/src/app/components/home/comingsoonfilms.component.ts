import {Component} from '@angular/core';

@Component({
  selector:'comingsoon-flims',
  template:`<div>
        <div class="dividing-line">
          <div class="upcoming">
            即将上映
          </div>
        </div>
        <ul>

        </ul>
      </div>`,
  styleUrls:['./comingsoonfilms.component.less']
})

export class ComingSoonFilmsComponent{}
