import { Component } from '@angular/core';

@Component({
  selector: "billboard-carousel",
  template:`
  <div class="myslides">

  </div>`
})

export class BillboardCarouselComponent{ }
