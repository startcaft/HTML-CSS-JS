<template>
  <div>
    <!-- <img src="./assets/logo.png"> -->
    <router-view keep-alive transition transition-mode="out-in"></router-view>
  </div>
</template>

<script>
export default {
  components:{}
}
</script>

<style>
</style>
