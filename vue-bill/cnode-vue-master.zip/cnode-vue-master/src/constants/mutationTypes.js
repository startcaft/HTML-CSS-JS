export const GET_TOPIC_LIST = 'GET_TOPIC_LIST';
export const UPDATE_TOPIC_LIST = 'UPDATE_TOPIC_LIST';
export const GET_TOPIC_INFO = 'GET_TOPIC_INFO';
export const LOGIN = 'LOGIN';
export const LOGIN_OUT = 'LOGIN_OUT';
export const REPLY = 'REPLY';
export const TOOGLE_LOAD = 'TOOGLE_LOAD';
export const TOOGLE_LIST_LOAD = 'TOOGLE_LIST_LOAD';

